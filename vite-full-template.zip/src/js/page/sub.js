

document.addEventListener('DOMContentLoaded', () => {
  console.log('🟢 sub.js 로드됨!')
})
